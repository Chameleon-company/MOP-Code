export const useCases = [
  {
    id: "business-and-economy",
    title: "Business and Economy",
    description:
      "Analyze market trends and financial data to optimize business strategies and drive economic growth.",
    image: "/img/insights/eco.webp",
    subUseCases: [
      {
        heading: "Coworking spaces",
        description:
          "Leverage AI to analyze market trends and predict customer behavior.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/Coworking_spaces.html",
      },
      {
        heading: "Enhancing job accessibility and opportunities in Melbourne",
        description:
          "Use predictive analytics to forecast revenues and optimize investments.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Business energy consumption",
        description:
          "Identify potential risks and develop strategies to mitigate financial losses.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Job forecasting",
        description:
          "Identify potential risks and develop strategies to mitigate financial losses.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Top hotspots for business and its activities",
        description:
          "Identify potential risks and develop strategies to mitigate financial losses.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Business Activity Cafes & Restaurants",
        description:
          "Identify potential risks and develop strategies to mitigate financial losses.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
    ],
  },

  {
    id: "community-and-social-impact",
    title: "Community and Social Impact",
    description:
      "Develop initiatives and solutions that enhance social welfare and create positive community outcomes.",
    image: "/img/insights/community.webp",
    subUseCases: [
      {
        heading: "Accessibility",
        description:
          "Organize and track volunteer initiatives using smart management tools.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Melbourne Social Trend",
        description:
          "Launch projects that directly improve local communities’ wellbeing.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Community Wellbeing",
        description:
          "Use data to evaluate the impact of social and charity initiatives.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/CommunityWellbeing.html",
      },
      {
        heading: "Social indicator changes",
        description:
          "Use data to evaluate the impact of social and charity initiatives.",
        image: "/img/social_indicator.jpg",
        link: "/dummypages/UC00077_Social_Indicator_Changes.html",
      },
    ],
  },

  {
    id: "education-and-teaching",
    title: "Education and Teaching",
    description:
      "Leverage AI and digital tools to improve learning experiences and personalize education for all students.",
    image: "/img/insights/teach.avif",
    subUseCases: [
      {
        heading: "Childcare Facility",
        description:
          "AI adapts lessons to individual student needs for better outcomes.",
        image: "/img/insights/ChldC.jpeg",
        link: "/dummypages/Childcare_Facilities.html",
      },
      {
        heading: "Optimizing school infrastructure planning",
        description:
          "Interactive online teaching platforms with real-time collaboration tools.",
        image: "/img/insights/OSI.png",
        link: "/dummypages/UC00145_Optimising_School_Infrastructure_Planning.html",
      },
    ],
  },
  {
    id: "environmental-sustainability",
    title: "Environmental Sustainability",
    description:
      "Implement eco-friendly technologies and strategies to protect natural resources and combat climate change.",
    image: "/img/insights/envi.jpg",
    subUseCases: [
      {
        heading: "Enhancing Urban Tree Planting through air quality analysis",
        description:
          "Use AI to optimize energy consumption in industries and cities.",
        image: "/img/tree_planting.jpeg",
        link: "/dummypages/UC00149_Enhancing_Urban_Tree_Planting_through_Air_Quality_Analysis.html",
      },
      {
        heading: "Waste Efficiency Argyle Square case study",
        description:
          "Intelligent systems to manage recycling and reduce environmental impact.",
        image: "/img/waste_efficiency.jpg",
        link: "/dummypages/UC00150_Waste_Efficiency_Argyle_Square_case_study.html",
      },
      {
        heading:
          "Evaluating the impact of urban Heat Islands on Community Wellbeing",
        description:
          "Analyze climate data to predict trends and take preventive measures.",
        image: "/img/heat_island.png",
        link: "/dummypages/UC00152_Evaluating_the_Impact_of_Urban_Heat_Islands_on_Community_Wellbeing.html",
      },
      {
        heading: "Biodiversity corridors creation Melbourne",
        description:
          "Analyze climate data to predict trends and take preventive measures.",
        image: "/img/bio_corridor.jpg",
        link: "/dummypages/UC00153_Biodiversity_corridors_creation_melbourne2025.html",
      },
      {
        heading: "Sustainable mobility and Emission Reduction in Melbourne",
        description:
          "Analyze climate data to predict trends and take preventive measures.",
        image: "/img/sustainable_mobility.jpg",
        link: "/dummypages/UC00158_Sustainable_Mobility_and_Emission_Reduction_in_Melbourne.html",
      },
      {
        heading: "AI Driven Wildfire Risk Assessment and Hotspot Prediction",
        description:
          "Analyze climate data to predict trends and take preventive measures.",
        image: "/img/AI_fire.jpg",
        link: "",
      },
      {
        heading: "Heat Vulnerability Mapping",
        description:
          "Analyze climate data to predict trends and take preventive measures.",
        image: "/img/heat_map.png",
        link: "/dummypages/UC00169_Heat_Vulnerability_Mapping.html",
      },
      {
        heading: "Melbourne Urban Microclimate Dynamics",
        description:
          "Analyze climate data to predict trends and take preventive measures.",
        image: "/img/urban_climate.jpg",
        link: "/dummypages/UC00171_Melbourne_Urban_Microclimate_Dynamics.html",
      },
      {
        heading: "Climate change Impact Simulation",
        description:
          "Analyze climate data to predict trends and take preventive measures.",
        image: "/img/climate_change.jpg",
        link: "/dummypages/UC00167_Climate_Change_Impact_Simulation.html",
      },
      {
        heading: "Tracking unique insect species in Melbourne",
        description:
          "Analyze climate data to predict trends and take preventive measures.",
        image: "/img/unique_insects.jpg",
        link: "/dummypages/UC00042_Tracking_Unique_Insect_Species_in_City_of_Melbourne.html",
      },
    ],
  },
  {
    id: "safety-and-security",
    title: "Safety and Security",
    description:
      "Deploy intelligent systems to ensure public safety, prevent threats, and maintain secure environments.",
    image: "/img/insights/safety.jpg",
    subUseCases: [
      {
        heading: "Night time safety Index",
        description:
          "AI-powered cameras and monitoring systems for public safety.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/Night_Time_Safety_Index.html",
      },
      {
        heading: "Populations and Accidents",
        description:
          "Intelligent systems that detect anomalies and prevent security breaches.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Pedestrian Accidents and Bus stops",
        description:
          "Optimized emergency response using predictive analytics and real-time alerts.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
    ],
  },
  {
    id: "tourism-and-hospitality",
    title: "Tourism and Hospitality",
    description:
      "Enhance travel experiences with personalized recommendations, smart bookings, and efficient service management.",
    image: "/img/insights/tours.jpeg",
    subUseCases: [
      {
        heading: "Optimizing event locations and urban management in Melbourne",
        description:
          "AI-driven booking systems for hotels, flights, and experiences.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/Optimizing_Event_Locations.html",
      },
      {
        heading: "Cultural tourism route optimisation",
        description:
          "Tailored travel suggestions based on preferences and history.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading:
          "Optimising tourist accommodation through landmark and parking",
        description:
          "Enhance hospitality services using real-time analytics and feedback.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
    ],
  },
  {
    id: "transport-and-mobility",
    title: "Transport and Mobility",
    description:
      "Improve urban mobility and transportation systems through AI-driven traffic management and smart solutions.",
    image: "/img/insights/transport.jpeg",
    subUseCases: [
      {
        heading: "Optimising parking accessibility near healthcare and education",
        description:
          "AI optimizes traffic flow and reduces congestion in real-time.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/Optimising_Parking_Accessibility_Near_Healthcare_and_Education.html",
      },
      {
        heading: "Smart Urban mobility",
        description:
          "Integrate AI for safer and more efficient self-driving solutions.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Parking availability Melbourne",
        description:
          "Enhance city transit systems using passenger and route data.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Bike usage",
        description:
          "Enhance city transit systems using passenger and route data.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Traffic congestion and parking zone impact",
        description:
          "Enhance city transit systems using passenger and route data.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Parking slot occupany",
        description:
          "Enhance city transit systems using passenger and route data.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Public Transport Demand",
        description:
          "Enhance city transit systems using passenger and route data.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Bike route optimization",
        description:
          "Enhance city transit systems using passenger and route data.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
    ],
  },
  {
    id: "urban-planing-and-development",
    title: "Urban Planning and Development",
    description:
      "Design smarter cities by integrating AI, IoT, and sustainable planning to optimize infrastructure and resources.",
    image: "/img/insights/plan.webp",
    subUseCases: [
      {
        heading: "Real Estate",
        description:
          "Use AI and IoT to manage utilities, roads, and buildings efficiently.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Population growth & Active Transportation",
        description:
          "Integrate eco-friendly designs and green spaces in urban projects.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/Population_Growth_&_Active_Transportation_Needs_Analysis.html",
      },
      {
        heading: "Urban Development analysis",
        description:
          "Analyze city data to optimize energy, water, and transportation usage.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Bin fill levels",
        description:
          "Analyze city data to optimize energy, water, and transportation usage.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "City Living comfort",
        description:
          "Analyze city data to optimize energy, water, and transportation usage.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Capacity forecasting and strategic insights",
        description:
          "Analyze city data to optimize energy, water, and transportation usage.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Route planner",
        description:
          "Analyze city data to optimize energy, water, and transportation usage.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Optimising public amenities in Melbourne",
        description:
          "Analyze city data to optimize energy, water, and transportation usage.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
    ],
  },
  {
    id: "helth-and-wellbeign",
    title: "Health and Wellbeing",
    description:
      "Utilize predictive analytics and AI to enhance healthcare outcomes and promote overall wellbeing.",
    image: "/img/insights/health.jpg",
    subUseCases: [
      {
        heading: "Mental Wellbeing",
        description:
          "AI predicts patient risks and recommends proactive care measures.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/UC00058_Mental_Wellbeing.html",
      },
      {
        heading: "Enhancing community wellbeing through public transport",
        description:
          "Remote consultation platforms with intelligent diagnostic support.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/UC00076_Enhancing_Community_Wellbeing_Through_Public_Transport.html",
      },
      {
        heading: "Food Services and its impact on wellbeing indicators",
        description:
          "Monitor lifestyle and health metrics to improve daily wellbeing.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
      {
        heading: "Impact of Coworking spaces on social wellbeing indicators",
        description:
          "Monitor lifestyle and health metrics to improve daily wellbeing.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "/dummypages/UC00096_Impact_of_Coworking_Spaces_on_Social_Wellbeing_Indicators.html",
      },
      {
        heading: "Optimization of outdoor fitness activities (2025)",
        description:
          "Monitor lifestyle and health metrics to improve daily wellbeing.",
        image: "/img/2bafb41a2f7d47daa950025568befe0218893c90-2880x1440.avif",
        link: "",
      },
    ],
  },
];

//edits for recent case studies
export const recentCaseStudies = [
  {
    id: "biotechnology",
    title: "Biotechnology",
    description:
      "Explore how biotechnology leverages Melbourne's open data to drive innovation in healthcare, research, and sustainable solutions. - dummy data",
    image: "/img/biotech.jpeg",
  },
  {
    id: "oil-supply-management",
    title: "Oil Supply Management",
    description:
      "Analyze supply chain efficiency and demand forecasting in oil distribution using data-driven insights from Melbourne. - dummy data",
    image: "/img/Oil-Supply.jpg",
  },
  {
    id: "gas-supply-management",
    title: "Gas Supply Management",
    description:
      "Utilize real-time data to optimize gas supply networks, improve distribution, and ensure energy sustainability. - dummy data",
    image: "/img/gas-supply.png",
  },
  {
    id: "education",
    title: "Education",
    description:
      "Enhance learning outcomes through data-driven decision-making and smart education systems powered by Melbourne's open data. - dummy data",
    image: "/img/education.jpg",
  },
];

export const blogs = [ /* ...your blog data... */ ];

