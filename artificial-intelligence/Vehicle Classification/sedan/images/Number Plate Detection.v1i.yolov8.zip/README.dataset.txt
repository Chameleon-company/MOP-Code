# Number Plate Detection > 2023-05-16 8:55pm
https://universe.roboflow.com/spooky/number-plate-detection-gq6xc

Provided by a Roboflow user
License: Public Domain

